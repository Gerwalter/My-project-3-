using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trap : MonoBehaviour
{
    public LayerMask targetLayerName; // Nombre de la capa de los boids, cambia este valor seg�n tu configuraci�n

    private void OnTriggerEnter(Collider other)
    {
        // Verifica si el objeto colisionado tiene la capa especificada
        if (other.gameObject.layer == targetLayerName)
        {
            Destroy(other.gameObject); // Mata al boid
            Destroy(this.gameObject);  // Opcional: destruye la trampa tras usarse
        }
    }
}
