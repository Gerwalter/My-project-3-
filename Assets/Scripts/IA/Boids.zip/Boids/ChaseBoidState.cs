using UnityEngine;

public class ChaseBoidState : IState
{
    private Hunter _hunter;

    public ChaseBoidState(Hunter hunter)
    {
        _hunter = hunter;
    }

    public void OnEnter()
    {
        _hunter.SetColor(Color.blue);
    }

    public void OnUpdate()
    {
        if (_hunter.TargetBoid == null)
        {
            _hunter.StateMachine.ChangeState(HunterStates.Wander);
            return;
        }

        float distance = Vector3.Distance(_hunter.transform.position, _hunter.TargetBoid.position);

        // Si el boid est� fuera del rango, dejar de perseguir
        if (distance > _hunter.detectionRadius + 1f)
        {
            _hunter.TargetBoid = null;
            _hunter.StateMachine.ChangeState(HunterStates.Wander);
            return;
        }

        // Eliminar el boid si lo toca
        if (distance < 1.2f) // puedes ajustar este umbral
        {
            GameObject.Destroy(_hunter.TargetBoid.gameObject);
            _hunter.TargetBoid = null;
            _hunter.StateMachine.ChangeState(HunterStates.Rest);
            return;
        }

        // Seguir persiguiendo
        Vector3 chase = _hunter.Seek(_hunter.TargetBoid.position);
        _hunter.AddForce(chase);
    }

    public void OnExit() { }
}
