using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance { get; private set; }

    [Header("L�mites del Mundo")]
    public Vector2 worldMin = new Vector2(-50f, -50f);
    public Vector2 worldMax = new Vector2(50f, 50f);

    [Header("Par�metros de Flocking")]
    [Range(0f, 5f)] public float separationWeight = 1.5f;
    [Range(0f, 5f)] public float alignmentWeight = 1.0f;
    [Range(0f, 5f)] public float cohesionWeight = 1.0f;
    [Range(0f, 5f)] public float hunterDetection;
    [Range(0f, 5f)] public float foodDetection;

    [Header("Rangos de Comportamiento")]
    public float cohesionAlignmentRadius = 5f;
    public float separationRadius = 2f;
    public bool visible;

    [Space(25), Header("Lista de Boids")]
    public List<Boid> myBoids = new();

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }
    }


    public Vector3 GetPosition(Vector3 position)
    {
        float x = position.x;
        float z = position.z;

        if (x < worldMin.x) x = worldMax.x;
        else if (x > worldMax.x) x = worldMin.x;

        if (z < worldMin.y) z = worldMax.y;
        else if (z > worldMax.y) z = worldMin.y;

        return new Vector3(x, position.y, z);
    }


    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Vector3 center = new Vector3((worldMin.x + worldMax.x) / 2f, 0f, (worldMin.y + worldMax.y) / 2f);
        Vector3 size = new Vector3(worldMax.x - worldMin.x, 0f, worldMax.y - worldMin.y);
        Gizmos.DrawWireCube(center, size);
    }

    public Vector3 GetRandomPosition()
    {
        float x = Random.Range(worldMin.x, worldMax.x);
        float z = Random.Range(worldMin.y, worldMax.y);
        return new Vector3(x, 0, z);
    }
}
