using UnityEngine;

public class TrapState : IState
{
    private Hunter _hunter;
    private float _trapDelay = 1.5f;
    private float _timer;

    public TrapState(Hunter hunter)
    {
        _hunter = hunter;
    }

    public void OnEnter()
    {
        _timer = _trapDelay;
        _hunter.SetColor(Color.magenta); // Opcional: indica modo trampa
        _hunter.Stop(); // Se detiene antes de poner la trampa
    }

    public void OnUpdate()
    {
        _timer -= Time.deltaTime;
        if (_timer <= 0f)
        {
            PlaceTrap();
            _hunter.StateMachine.ChangeState(HunterStates.Wander);
        }
    }

    public void OnExit() { }

    private void PlaceTrap()
    {
        if (_hunter.trapPrefab != null)
        {
            GameObject.Instantiate(_hunter.trapPrefab, _hunter.transform.position, Quaternion.identity);
        }
    }
}