using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flee : IState
{
    private Boid _boid;
    private Transform _targetHunter;

    public Flee(Boid boid)
    {
        _boid = boid;
        _targetHunter = null;
    }

    public void OnEnter()
    {
        _boid.SetColor(Color.yellow);
    }

    public void OnUpdate()
    {
        // Buscar cazador m�s cercano
        if (_targetHunter == null)
        {
            Collider[] hunters = Physics.OverlapSphere(_boid.transform.position, GameManager.instance.hunterDetection, _boid.HunterLayer);
            if (hunters.Length > 0)
            {
                _targetHunter = hunters[0].transform;
            }
            else
            {
                _boid.StateMachine.ChangeState(AgentStates.Wander);
                return;
            }
        }

        // Huir del cazador
        Vector3 steering = _boid.Escape(_targetHunter.position);
        _boid.SendMessage("AddForce", steering);

        float distance = Vector3.Distance(_boid.transform.position, _targetHunter.position);

        // Si el boid logr� alejarse lo suficiente, volver a vagar
        if (distance > GameManager.instance.hunterDetection + 1f)
        {
            _targetHunter = null;
            _boid.StateMachine.ChangeState(AgentStates.Wander);
        }
    }

    public void OnExit()
    {
        _targetHunter = null;
    }
}
