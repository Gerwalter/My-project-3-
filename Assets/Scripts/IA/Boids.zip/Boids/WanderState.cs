using UnityEngine;

public class WanderState : IState
{
    private Boid _boid;
    private float _foodDetectionRadius;
    private float _hunterDetectionRadius;

    public WanderState(Boid boid)
    {
        _boid = boid;
        _foodDetectionRadius = GameManager.instance.foodDetection;
        _hunterDetectionRadius = GameManager.instance.hunterDetection;
    }

    public void OnEnter()
    {
        _boid.SetColor(Color.white);
    }

    public void OnUpdate()
    {
        _boid.Flocking();

        // Detectar hunters
        Collider[] hunters = Physics.OverlapSphere(_boid.transform.position, _hunterDetectionRadius, _boid.HunterLayer);
        if (hunters.Length > 0)
        {
            _boid.StateMachine.ChangeState(AgentStates.Flee);
            return;
        }

        // Detectar comida
        Collider[] food = Physics.OverlapSphere(_boid.transform.position, _foodDetectionRadius, _boid.FoodLayer);
        if (food.Length > 0)
        {
            _boid.StateMachine.ChangeState(AgentStates.SeekFood);
        }
    }

    public void OnExit()
    {
        // Nada por ahora
    }
}
