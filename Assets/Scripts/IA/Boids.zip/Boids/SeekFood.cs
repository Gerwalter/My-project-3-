using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeekFood: IState
{
    private Boid _boid;
    private Transform _targetFood;
    public SeekFood(Boid boid)
    {
        _boid = boid;
    }

    public void OnEnter()
    {
        _boid.SetColor(Color.cyan);
        _targetFood = null;
    }

    public void OnUpdate()
    {
        // Si no hay comida objetivo, buscarla
        if (_targetFood == null)
        {
            Collider[] food = Physics.OverlapSphere(_boid.transform.position, GameManager.instance.foodDetection, _boid.FoodLayer);
            if (food.Length > 0)
            {
                _targetFood = food[0].transform;
            }
            else
            {
                _boid.StateMachine.ChangeState(AgentStates.Wander);
                return;
            }
        }

        // Moverse hacia la comida
        Vector3 steering = _boid.Arrive(_targetFood.position, 3f);
        _boid.SendMessage("AddForce", steering);

        // �Est� lo suficientemente cerca como para "comer"?

        float distance = Vector3.Distance(_boid.transform.position, _targetFood.position);
        if (distance < 0.5f)
        {
            GameObject.Destroy(_targetFood.gameObject); // "Consume" la comida
            _targetFood = null;
            _boid.StateMachine.ChangeState(AgentStates.Wander);
        }
    }

    public void OnExit()
    {
        _targetFood = null;
    }
}
