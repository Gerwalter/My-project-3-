using UnityEngine;

public class HunterWanderState : IState
{
    private Hunter _hunter;
    private float _timer = 0f;
    private float _trapInterval = 5f;

    public HunterWanderState(Hunter hunter)
    {
        _hunter = hunter;
    }

    public void OnEnter()
    {
        _hunter.SetColor(Color.green);
        _timer = 0f; // Resetea el temporizador cuando entras en el estado "Wander"
    }

    public void OnUpdate()
    {
        _timer += Time.deltaTime;

        Collider[] boids = Physics.OverlapSphere(_hunter.transform.position, GameManager.instance.hunterDetection, _hunter.BoidLayer);
        if (boids.Length > 0)
        {
            _hunter.TargetBoid = boids[0].transform;
            _hunter.StateMachine.ChangeState(HunterStates.ChaseBoid);
            return;
        }

        if (_timer >= _trapInterval)
        {
            _hunter.StateMachine.ChangeState(HunterStates.Trap);
            return;
        }

        Vector3 target = _hunter.GetCurrentWaypoint();
        Vector3 steering = _hunter.Pursue(target);
        _hunter.AddForce(steering);


        if (Vector3.Distance(_hunter.transform.position, target) < 1.5f)
        {
            _hunter.AdvanceWaypoint();
        }

    }
    public void OnExit() { }
}
