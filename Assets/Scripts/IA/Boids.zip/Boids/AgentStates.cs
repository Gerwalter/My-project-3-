public enum AgentStates
{
    Wander,
    SeekFood,
    Flee
}
public enum HunterStates
{
    Wander,
    ChaseBoid,
    Rest,
    Trap
}