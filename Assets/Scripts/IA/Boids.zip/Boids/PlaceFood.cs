using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceFood: MonoBehaviour
{
    public GameObject food;
    public GameObject Boid;

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Click izquierdo
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                Vector3 posicion = hit.point;
                posicion.y = 0;
                Instantiate(food, posicion, Quaternion.identity);
            }
        }

        if (Input.GetMouseButtonDown(1)) // Click izquierdo
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // Hacer raycast contra cualquier collider en la escena
            if (Physics.Raycast(ray, out hit))
            {
                Vector3 posicion = hit.point;
                posicion.y = 0; // Forzar Y en 0
                Instantiate(Boid, posicion, Quaternion.identity);
            }
        }
    }
}
