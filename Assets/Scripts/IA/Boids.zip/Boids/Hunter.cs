using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hunter : MonoBehaviour
{
    private FSM<HunterStates> _fsm;

    [Header("Movimiento")]
    public float maxSpeed = 5f;
    public float maxForce = 10f;
    public float turnSpeed = 10f;
    private Vector3 _velocity;
    private Vector3 _acceleration;
    
    public GameObject trapPrefab;

    [Header("Detecci�n")]
    public LayerMask BoidLayer;
    public float detectionRadius = 5f;
    public Transform TargetBoid { get; set; }

    void Start()
    {
        _fsm = new FSM<HunterStates>();
        _fsm.AddState(HunterStates.Wander, new HunterWanderState(this));
        _fsm.AddState(HunterStates.ChaseBoid, new ChaseBoidState(this));
        _fsm.AddState(HunterStates.Rest, new Rest(this));
        _fsm.AddState(HunterStates.Trap, new TrapState(this));
        _fsm.ChangeState(HunterStates.Wander);

        AddForce(new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)) * maxSpeed);
    }

    void Update()
    {
        _fsm.ArtificialUpdate();
        Move();
    }

    public FSM<HunterStates> StateMachine => _fsm;

    public void AddForce(Vector3 force)
    {
        _acceleration += force;
    }

    public void SetColor(Color color)
    {
        GetComponent<Renderer>().material.color = color;
    }

    private void Move()
    {
        _velocity += _acceleration;
        _velocity = Vector3.ClampMagnitude(_velocity, maxSpeed);
        transform.position += _velocity * Time.deltaTime;
        _acceleration = Vector3.zero;

        if (_velocity.sqrMagnitude > 0.01f)
            transform.forward = _velocity.normalized;

        // Reubicarse si est� fuera del mundo
        transform.position = GameManager.instance.GetPosition(transform.position);
    }
    public void Stop()
    {
        _velocity = Vector3.zero;
        _acceleration = Vector3.zero;
    }
    public Vector3 Seek(Vector3 target)
    {
        Vector3 desired = (target - transform.position).normalized * maxSpeed;
        Vector3 steer = desired - _velocity;
        return Vector3.ClampMagnitude(steer, maxForce * Time.deltaTime);
    }

    public Vector3 Pursue(Vector3 targetPosition)
    {
        Vector3 direction = (targetPosition - transform.position).normalized;

        // Mover hacia el objetivo
        transform.position += direction * maxSpeed * Time.deltaTime;

        // Rotar hacia la direcci�n de movimiento
        if (direction != Vector3.zero)
        {
            Quaternion lookRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * turnSpeed);
        }

        return direction * maxSpeed; // Devuelve el vector de movimiento por si quieres usarlo
    }

    private void OnDrawGizmos()
    {
        if (!Application.isPlaying) return;
        if (GameManager.instance.visible)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, detectionRadius);
        }
    }
    public Transform[] waypoints;
    private int currentWaypointIndex = 0;

    public Vector3 GetCurrentWaypoint()
    {
        return waypoints[currentWaypointIndex].position;
    }

    public void AdvanceWaypoint()
    {
        currentWaypointIndex = (currentWaypointIndex + 1) % waypoints.Length;
    }
}
