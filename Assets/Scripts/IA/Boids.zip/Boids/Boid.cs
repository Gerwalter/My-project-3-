using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boid : MonoBehaviour
{
    protected Vector3 _velocity;
    public Vector3 Velocity { get { return _velocity; } }

    [SerializeField, Range(0f, 10f)] protected float _maxVelocity;
    [SerializeField, Range(0f, 5f)] protected float _maxForce;
    private FSM<AgentStates> _fsm;
    public FSM<AgentStates> StateMachine => _fsm;
    void Start()
    {
        GameManager.instance.myBoids.Add(this);
        _fsm = new FSM<AgentStates>();

        _fsm.AddState(AgentStates.Wander, new WanderState(this));
        _fsm.AddState(AgentStates.SeekFood, new SeekFood(this));
        _fsm.AddState(AgentStates.Flee, new Flee(this));

        _fsm.ChangeState(AgentStates.Wander);

        AddForce(new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)) * _maxVelocity);
    }
    protected void AddForce(Vector3 dir)         //Current Velocity
    {
        _velocity = Vector3.ClampMagnitude(_velocity + dir, _maxVelocity);
    }

    [SerializeField] private MeshRenderer _meshR;

    public void SetColor(Color color)
    {
        if (_meshR != null)
            _meshR.material.color = color;
    }
    public Vector3 Seek(Vector3 desired)
    {
        //Desired Velocity
        desired = desired.normalized;
        desired *= _maxVelocity;

        //Steering
        Vector3 steering = desired - _velocity;
        steering = Vector3.ClampMagnitude(steering, _maxForce * Time.deltaTime);//Ojo
        return steering;
    }

    public Vector3 Flee(Vector3 target) => -Seek(target);

    [SerializeField] private LayerMask foodLayer;
    public LayerMask FoodLayer { get { return foodLayer; } }

    [SerializeField] private LayerMask hunterLayer;

    public LayerMask HunterLayer { get { return hunterLayer; } }
    // Update is called once per frame
    void Update()
    {
        _fsm.ArtificialUpdate();

        transform.position += _velocity * Time.deltaTime;
        if (_velocity != Vector3.zero) transform.forward = _velocity;
        transform.position = GameManager.instance.GetPosition(transform.position);
    }
    public void Flocking()
    {
        AddForce(Cohesion(GameManager.instance.myBoids, GameManager.instance.cohesionAlignmentRadius) * GameManager.instance.cohesionWeight);
        AddForce(Separation(GameManager.instance.myBoids, GameManager.instance.separationRadius) * GameManager.instance.separationWeight);
        AddForce(Alignment(GameManager.instance.myBoids, GameManager.instance.cohesionAlignmentRadius) * GameManager.instance.alignmentWeight);
    }
    private Vector3 Cohesion(List<Boid> boids, float radius)
    {
        Vector3 desired = Vector3.zero;
        int count = 0;

        foreach (Boid boid in boids)
        {
            if (Vector3.Distance(transform.position, boid.transform.position) > radius || boid == this) continue;

            count++;
            desired += boid.transform.position;
        }

        if (count <= 0) return Vector3.zero;

        desired /= count;

        //desired -= transform.position;

        return Seek(desired);
    }
    public Vector3 Escape(Vector3 target) => -Arrive(target);
    private Vector3 Separation(List<Boid> boids, float radius)
    {
        Vector3 desired = Vector3.zero;

        foreach (Boid boid in boids)
        {
            var dir = boid.transform.position - transform.position;

            if (dir.magnitude > radius || boid == this) continue;

            desired -= dir;
        }

        if (desired == Vector3.zero) return Vector3.zero;

        return Seek(desired);
    }

    private Vector3 Alignment(List<Boid> boids, float radius)
    {
        Vector3 desired = Vector3.zero;
        int count = 0;

        foreach (Boid boid in boids)
        {
            if (Vector3.Distance(transform.position, boid.transform.position) > radius || boid == this) continue;

            count++;
            desired += boid.Velocity;
        }

        if (count <= 0) return Vector3.zero;

        desired /= count;

        return Seek(desired);
    }

    private void OnDrawGizmos()
    {
        if (!Application.isPlaying) return;
        if (GameManager.instance.visible)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.separationRadius);

            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.cohesionAlignmentRadius);

            Gizmos.color = Color.blue;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.separationWeight);

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.alignmentWeight);

            Gizmos.color = Color.black;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.cohesionWeight);

            Gizmos.color = Color.white;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.hunterDetection);

            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, GameManager.instance.foodDetection);
        }
    }

    public Vector3 Arrive(Vector3 target, float slowingRadius = 3f)
    {
        Vector3 desired = target - transform.position;
        float distance = desired.magnitude;

        if (distance < 0.1f) return Vector3.zero; // ya lleg�

        float speed = _maxVelocity;
        if (distance < slowingRadius)
        {
            speed = Mathf.Lerp(0, _maxVelocity, distance / slowingRadius);
        }

        desired = desired.normalized * speed;

        Vector3 steering = desired - _velocity;
        steering = Vector3.ClampMagnitude(steering, _maxForce * Time.deltaTime);
        return steering;
    }
    private void OnDestroy()
    {
        GameManager.instance.myBoids.Remove(this);
    }

}
