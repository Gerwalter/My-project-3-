using UnityEngine;

public class Rest : IState
{
    private Hunter _hunter;
    private float _restDuration = 3f; // segundos
    private float _timer;

    public Rest(Hunter hunter)
    {
        _hunter = hunter;
    }

    public void OnEnter()
    {
        _timer = _restDuration;
        _hunter.SetColor(Color.black);

        // Detener completamente el movimiento
        _hunter.Stop();
    }

    public void OnUpdate()
    {
        _timer -= Time.deltaTime;
        if (_timer <= 0f)
        {
            _hunter.StateMachine.ChangeState(HunterStates.Wander);
        }
    }

    public void OnExit() { }
}
