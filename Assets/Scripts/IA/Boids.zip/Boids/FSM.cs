using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FSM<T> where T : System.Enum
{
    private Dictionary<T, IState> _states = new Dictionary<T, IState>();
    private IState _currentState;
    private T _currentKey;

    public void AddState(T key, IState state)
    {
        if (!_states.ContainsKey(key))
        {
            _states.Add(key, state);
        }
    }

    public void ChangeState(T key)
    {
        if (_states.TryGetValue(key, out var newState))
        {
            _currentState?.OnExit();
            _currentState = newState;
            _currentKey = key;
            _currentState.OnEnter();
        }
    }

    public void ArtificialUpdate()
    {
        _currentState?.OnUpdate();
    }

    public T CurrentKey => _currentKey;
}
